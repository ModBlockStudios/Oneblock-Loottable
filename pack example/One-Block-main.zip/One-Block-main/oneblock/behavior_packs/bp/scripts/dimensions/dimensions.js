import aeris from "./aeris";
import arkash from "./arkash";
import azural from "./azural";
import canopea from "./canopea";
import cryosis from "./cryosis";
import moltan from "./moltan";
import nether from "./nether";
import nox from "./nox";
import overworld from "./overworld";
import the_end from "./the_end";

export const DIMENSIONS = {
  aeris,
  arkash,
  azural,
  canopea,
  cryosis,
  moltan,
  nether,
  nox,
  overworld,
  the_end,
};
