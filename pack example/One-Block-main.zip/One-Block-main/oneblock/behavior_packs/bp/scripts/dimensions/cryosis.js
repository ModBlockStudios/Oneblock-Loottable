import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:cryosis`,
  displayName: `dimension.${NAMESPACE}:cryosis.name`,
  fog: `${NAMESPACE}:fog_cryosis`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:ice",
          weight: 1,
        },
        {
          name: "minecraft:packed_ice",
          weight: 1,
        },
        {
          name: "minecraft:blue_ice",
          weight: 1,
        },
        {
          name: "minecraft:snow",
          weight: 2,
        },
      ],
    },
  ],
};
