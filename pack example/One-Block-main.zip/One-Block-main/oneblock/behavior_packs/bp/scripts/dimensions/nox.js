import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:nox`,
  displayName: `dimension.${NAMESPACE}:nox.name`,
  fog: `${NAMESPACE}:fog_nox`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:black_wool",
          weight: 1,
        },
      ],
    },
  ],
};
