import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:aeris`,
  displayName: `dimension.${NAMESPACE}:aeris.name`,
  fog: `${NAMESPACE}:fog_aeris`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:white_wool",
          weight: 1,
        },
      ],
    },
  ],
};
