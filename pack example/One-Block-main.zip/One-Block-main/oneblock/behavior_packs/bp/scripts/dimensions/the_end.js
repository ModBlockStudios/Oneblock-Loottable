export default {
  name: `minecraft:the_end`,
  displayName: `dimension.dimensionName2`,
  fog: `minecraft:fog_the_end`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:end_stone",
          weight: 1,
        },
      ],
    },
  ],
};
