import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:canopea`,
  displayName: `dimension.${NAMESPACE}:canopea.name`,
  fog: `${NAMESPACE}:fog_canopea`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:oak_leaves",
          weight: 2,
        },
        {
          name: "minecraft:moss_block",
          weight: 2,
        },
        {
          name: "minecraft:grass_block",
          weight: 2,
        },
      ],
    },
  ],
};
