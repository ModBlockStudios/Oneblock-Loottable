import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:arkash`,
  displayName: `dimension.${NAMESPACE}:arkash.name`,
  fog: `${NAMESPACE}:fog_arkash`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:cut_sandstone",
          weight: 2,
        },
        {
          name: "minecraft:sandstone",
          weight: 2,
        },
        {
          name: "minecraft:red_sandstone",
          weight: 2,
        },
        {
          name: "minecraft:cut_red_sandstone",
          weight: 2,
        },
      ],
    },
  ],
};
