import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:moltan`,
  displayName: `dimension.${NAMESPACE}:moltan.name`,
  fog: `${NAMESPACE}:fog_moltan`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:magma",
          weight: 1,
        },
        {
          name: "minecraft:stone",
          weight: 2,
        },
        {
          name: "minecraft:deepslate",
          weight: 2,
        },
        {
          name: "minecraft:blackstone",
          weight: 2,
        },
        {
          name: "minecraft:basalt",
          weight: 2,
        },
      ],
    },
  ],
};
