import { NAMESPACE } from "../config";

export default {
  name: `${NAMESPACE}:azural`,
  displayName: `dimension.${NAMESPACE}:azural.name`,
  fog: `${NAMESPACE}:fog_azural`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:sea_lantern",
          weight: 1,
        },
        {
          name: "minecraft:wet_sponge",
          weight: 2,
        },
      ],
    },
  ],
};
