export default {
  name: `minecraft:overworld`,
  displayName: `dimension.dimensionName0`,
  fog: `minecraft:fog_default`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:grass_block",
          weight: 1,
        },
      ],
    },
  ],
};
