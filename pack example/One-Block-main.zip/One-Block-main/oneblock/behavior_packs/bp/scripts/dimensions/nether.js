export default {
  name: `minecraft:nether`,
  displayName: `dimension.dimensionName1`,
  fog: `minecraft:fog_hell`,
  phases: [
    {
      blocks: [
        {
          name: "minecraft:netherrack",
          weight: 1,
        },
        {
          name: "minecraft:nether_brick",
          weight: 1,
        },
      ],
    },
  ],
};
