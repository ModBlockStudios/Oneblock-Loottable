import { BlockPermutation, system, world } from "@minecraft/server";
import { DIMENSIONS } from "./dimensions/dimensions";
import { NAMESPACE } from "./config";

system.beforeEvents.startup.subscribe(({ dimensionRegistry }) => {
  for (const dimConfig of Object.values(DIMENSIONS)) {
    if (dimConfig.name.startsWith(`${NAMESPACE}:`)) {
      dimensionRegistry.registerCustomDimension(dimConfig.name);
    }
  }
});

world.afterEvents.worldLoad.subscribe(() => {
  for (const dimConfig of Object.values(DIMENSIONS)) {
    setupDimension(dimConfig);
  }
});

world.afterEvents.playerDimensionChange.subscribe((event) => {
  const { player, toDimension } = event;
  const toConfig = getDimensionConfig(toDimension);
  toDimension.runCommand(`fog ${player.nameTag} remove dim`);
  toDimension.runCommand(`fog ${player.nameTag} push ${toConfig.fog} dim`);
});

async function setupDimension(dimConfig) {
  const dimension = world.getDimension(dimConfig.name);
  const tickingAreaId = `${dimConfig.name}_area`;

  await world.tickingAreaManager.createTickingArea(tickingAreaId, {
    dimension,
    from: { x: -2, y: -2, z: -2 },
    to: { x: 2, y: 2, z: 2 },
  });

  const block = dimension.getBlock({ x: 0, y: 0, z: 0 });
  if (block?.isAir) {
    const phase = dimConfig.phases[0];
    block.setPermutation(BlockPermutation.resolve(pickBlock(phase)));
  }

  world.tickingAreaManager.removeTickingArea(tickingAreaId);
}

function getDimensionConfig(dimension) {
  const [, name] = dimension.id.split(":");
  return DIMENSIONS[name];
}

world.afterEvents.playerBreakBlock.subscribe((event) => {
  const { x, y, z } = event.block.location;
  if (x !== 0 || y !== 0 || z !== 0) {
    return;
  }

  const dimConfig = getDimensionConfig(event.dimension);
  const phase = dimConfig.phases[0];

  event.block.setPermutation(BlockPermutation.resolve(pickBlock(phase)));

  const player = event.player;
  const loc = player.location;

  const min = {
    x: 0,
    y: 0,
    z: 0,
  };

  const max = {
    x: min.x + 1,
    y: min.y + 1,
    z: min.z + 1,
  };

  if (
    loc.x >= min.x &&
    loc.x <= max.x &&
    loc.y >= min.y &&
    loc.y <= max.y &&
    loc.z >= min.z &&
    loc.z <= max.z
  ) {
    player.teleport({ x: loc.x, y: 1, z: loc.z });
  }
});

function pickBlock(phase) {
  const blocks = phase.blocks;

  const total = blocks.reduce((sum, b) => sum + b.weight, 0);

  let r = Math.random() * total;

  for (const block of blocks) {
    r -= block.weight;
    if (r < 0) {
      return block.name;
    }
  }

  return blocks[blocks.length - 1].name;
}
